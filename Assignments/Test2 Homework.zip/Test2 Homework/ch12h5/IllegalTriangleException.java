public class IllegalTriangleException extends Exception{
   public IllegalTriangleException(String passedError){
      super(passedError);
   }
}
