public class IllegalRectangleException extends Exception{
   public void IllegalTriangleException(String errorMessage){
      super(ex);
   }
}
